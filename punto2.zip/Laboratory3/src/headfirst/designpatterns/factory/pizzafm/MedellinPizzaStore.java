package headfirst.designpatterns.factory.pizzafm;

public class MedellinPizzaStore extends PizzaStore {
    @Override
    Pizza createPizza(String item) {
        if (item.equals("cheese")) {
            return new MedellinStyleCheesePizza();
        } else if (item.equals("veggie")) {
            return new MedellinStyleVeggiePizza();
        } else if (item.equals("hawaiian")) {
            return new MedellinStyleHawaiianPizza();
        } else if (item.equals("pepperoni")) {
            return new MedellinStylePepperoniPizza();
        } else return null;
    }
}
