package headfirst.designpatterns.factory.pizzafm;

public class MedellinStyleCheesePizza extends Pizza {
    public MedellinStyleCheesePizza() {
        name = "Medellin Style 5 Cheese Pizza";
        dough = "Thick Conrnmeal Crust Dough";
        sauce = "Bittersweet Tomato Sauce";

        toppings.add("Cheddar Cheese");
        toppings.add("Cow Cheese");
        toppings.add("Emmental Cheese");
        toppings.add("Provolone Cheese");
        toppings.add("Goat Cheese");
        toppings.add("Parmesan Cheese");
    }

    void cut() {
        System.out.println("Cutting the pizza into triangular slices");
    }

    void bake(){
        System.out.println("Bake for 20 minutes at 240");
    }

}
