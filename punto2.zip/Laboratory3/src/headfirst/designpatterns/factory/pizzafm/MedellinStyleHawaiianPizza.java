package headfirst.designpatterns.factory.pizzafm;

public class MedellinStyleHawaiianPizza extends Pizza {
    public MedellinStyleHawaiianPizza() {
        name = "Medellin Style Hawaiian Pizza (instead of that disgusting thing)";
        dough = "Soft Conrnmeal Crust Dough";
        sauce = "Bittersweet Tomato Sauce";

        toppings.add("Mozzarella Cheese");
        toppings.add("Pineapple");
        toppings.add("Pork Ham");
        toppings.add("Bocadillo on the edge");
        toppings.add("Raisins");
    }

    void cut() {
        System.out.println("Cutting the pizza into triangular slices");
    }
}