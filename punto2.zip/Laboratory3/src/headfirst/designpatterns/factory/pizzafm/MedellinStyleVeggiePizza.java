package headfirst.designpatterns.factory.pizzafm;

public class MedellinStyleVeggiePizza extends Pizza {
    public MedellinStyleVeggiePizza() {
        name = "Medellin Style Veggie Pizza";
        dough = "Thick Conrnmeal Crust Dough";
        sauce = "Bittersweet Tomato Sauce";

        toppings.add("Sliced Mushrooms");
        toppings.add("Sliced Tomatoes");
        toppings.add("Spinach");
    }

    void cut() {
        System.out.println("Cutting the pizza into triangular slices");
    }
}
