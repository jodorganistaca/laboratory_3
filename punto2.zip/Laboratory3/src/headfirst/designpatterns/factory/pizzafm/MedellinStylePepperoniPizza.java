package headfirst.designpatterns.factory.pizzafm;

public class MedellinStylePepperoniPizza extends Pizza {
    public MedellinStylePepperoniPizza() {
        name = "Medellin Style Pepperoni Pizza";
        dough = "Thick Conrnmeal Crust Dough";
        sauce = "Bittersweet Tomato Sauce";

        toppings.add("Shredded Mozzarella Cheese");
        toppings.add("Sliced Sausages");
        toppings.add("Sliced Pepperoni");
        toppings.add("Pinch of Pepper");
        toppings.add("Basil");
    }

    void cut() {
        System.out.println("Cutting the pizza into triangular slices");
    }
}
