package headfirst.designpatterns.factory.pizzaaf;

public interface Dough {
	public String toString();
}
