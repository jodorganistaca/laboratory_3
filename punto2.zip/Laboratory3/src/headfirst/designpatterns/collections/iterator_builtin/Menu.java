package headfirst.designpatterns.collections.iterator_builtin;

import java.util.Iterator;

public interface Menu {
	public Iterator<String> createIterator();
}
