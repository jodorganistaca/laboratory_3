package headfirst.designpatterns.combining.decorator;

public interface Quackable {
	public void quack();
}
